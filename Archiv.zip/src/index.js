import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Caroussel from './containers/Caroussel';



ReactDOM.render(<Caroussel />, document.getElementById('root'));
