module.exports = {
    //...
    output: {
      path: path.resolve(__dirname, 'public/assets'),
      publicPath: 'https://cdn.intranet.hpa/keyfacts/assets',
      path: path.resolve(__dirname/, 'static'),
      publicPath: 'https://cdn.intranet.hpa/keyfacts/static',
    }
  };